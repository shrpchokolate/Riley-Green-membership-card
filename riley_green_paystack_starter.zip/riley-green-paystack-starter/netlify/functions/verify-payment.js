// Netlify Function: verify a Paystack transaction before reporting success.
exports.handler = async (event) => {
  if (event.httpMethod !== "GET") return { statusCode: 405, body: "Method not allowed" };
  const secret = process.env.PAYSTACK_SECRET_KEY;
  const reference = event.queryStringParameters?.reference;
  if (!secret || !reference || !/^RGFC-[A-Za-z0-9]+$/.test(reference)) return json(400, { error: "Missing or invalid reference." });

  try {
    const r = await fetch(`https://api.paystack.co/transaction/verify/${encodeURIComponent(reference)}`, {
      headers: { Authorization: `Bearer ${secret}` }
    });
    const result = await r.json();
    const tx = result.data;
    if (!r.ok || !result.status || !tx) return json(502, { error: "Could not verify transaction." });
    // A valid success must match NGN and have a positive amount.
    const verified = tx.status === "success" && tx.currency === "NGN" && Number(tx.amount) > 0;
    return json(200, { verified, reference: tx.reference, status: tx.status, currency: tx.currency, amount: tx.amount });
  } catch {
    return json(502, { error: "Could not reach the payment provider." });
  }
};

function json(statusCode, data) {
  return { statusCode, headers: { "Content-Type": "application/json", "Cache-Control": "no-store" }, body: JSON.stringify(data) };
}
