// Netlify Function: initialize Paystack transaction securely.
const CATALOG = {
  "Digital Fan Card": 500000,
  "Physical Fan Card": 1000000,
  "Digital + Physical Fan Card Bundle": 1300000
}; // Prices in kobo. Update these sample prices before launch.

exports.handler = async (event) => {
  if (event.httpMethod !== "POST") return { statusCode: 405, body: "Method not allowed" };
  const secret = process.env.PAYSTACK_SECRET_KEY;
  if (!secret) return json(500, { error: "Payment provider is not configured." });

  let body;
  try { body = JSON.parse(event.body || "{}"); } catch { return json(400, { error: "Invalid request." }); }
  const { email, customerName, delivery, items } = body;
  if (!email || !Array.isArray(items) || items.length < 1) return json(400, { error: "Email and items are required." });

  let amount = 0;
  const normalized = [];
  for (const item of items) {
    const unit = CATALOG[item.name];
    const qty = Number(item.qty);
    if (!unit || !Number.isInteger(qty) || qty < 1 || qty > 10) return json(400, { error: "Invalid product or quantity." });
    amount += unit * qty;
    normalized.push({ name: item.name, qty });
  }

  const reference = "RGFC-" + crypto.randomUUID().replace(/-/g, "");
  const siteUrl = process.env.URL || "";
  const payload = {
    email,
    amount,
    currency: "NGN",
    reference,
    callback_url: siteUrl ? `${siteUrl}/?payment=return` : undefined,
    metadata: {
      customer_name: String(customerName || "").slice(0, 120),
      delivery: String(delivery || "").slice(0, 80),
      items: normalized,
      custom_fields: [
        { display_name: "Fan club order", variable_name: "fan_club_order", value: reference }
      ]
    }
  };

  try {
    const r = await fetch("https://api.paystack.co/transaction/initialize", {
      method: "POST",
      headers: { Authorization: `Bearer ${secret}`, "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });
    const result = await r.json();
    if (!r.ok || !result.status || !result.data?.authorization_url) {
      return json(502, { error: result.message || "Payment initialization failed." });
    }
    return json(200, { authorization_url: result.data.authorization_url, reference: result.data.reference });
  } catch {
    return json(502, { error: "Could not reach the payment provider." });
  }
};

function json(statusCode, data) {
  return { statusCode, headers: { "Content-Type": "application/json", "Cache-Control": "no-store" }, body: JSON.stringify(data) };
}
