# Riley Green Fan Club — Paystack starter

This starter adds a Paystack hosted checkout flow to the fan-card prototype.

## Important before launch
- This is a starter integration, not a complete production membership/order-management system.
- Sample amounts in `netlify/functions/create-payment.js` are ₦5,000 / ₦10,000 / ₦13,000 (stored as kobo). Edit them before use.
- Configure the Paystack secret key as a Netlify environment variable named `PAYSTACK_SECRET_KEY`. Never put a secret key in `index.html`, public GitHub, or chat.
- Set `URL` to the deployed site's full URL (Netlify generally supplies this automatically).
- Deploy the project folder with Netlify, not by opening the HTML file locally. Netlify Functions require hosting.
- Use Paystack test keys and test transactions first; switch to live keys only after your Paystack account is approved and the site, pricing, terms, privacy, refund, and delivery details are ready.
- Verification currently checks transaction status, NGN, and positive amount. Before real fulfillment, also compare the verified amount and metadata against an order saved server-side, prevent duplicate fulfillment, and add a signed webhook/order database.
- This starter does not yet create user accounts, store purchases persistently, email digital cards, manage shipping, or lock content to paid memberships.

## Deploy
1. Create/sign in to a Netlify account.
2. Upload/deploy this folder (or connect it to a Git repository).
3. In Netlify site settings, add environment variable `PAYSTACK_SECRET_KEY` with your Paystack **test** secret key.
4. Deploy again and test the checkout.
5. Configure the Paystack callback URL and webhook settings as needed.
6. Do not launch live sales until you have tested payment verification and order fulfillment end-to-end.

## Files
- `index.html` — storefront and checkout UI
- `netlify/functions/create-payment.js` — server-side transaction initialization
- `netlify/functions/verify-payment.js` — server-side transaction verification
- `netlify.toml` — Netlify publish/functions configuration
